/** @type {import('next').NextConfig} */
const nextConfig = {
  /* config options here */
  images: {
    domains: ['images.unsplash.com'],
    unoptimized: true, // cPanel için gerekli
  },
  // output: 'export', // Static export - API routes için kapatıldı
  trailingSlash: true, // cPanel için önerilen
  // distDir: 'out', // Export dizini - API routes için kapatıldı
  eslint: {
    ignoreDuringBuilds: true, // Build sırasında ESLint hatalarını yoksay
  },
  typescript: {
    ignoreBuildErrors: true, // Build sırasında TypeScript hatalarını yoksay
  },
};

module.exports = nextConfig;
